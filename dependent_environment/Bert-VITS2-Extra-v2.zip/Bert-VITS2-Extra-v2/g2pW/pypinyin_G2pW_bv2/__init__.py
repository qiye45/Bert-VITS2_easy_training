# -*- coding: utf-8 -*-

from .g2pw import G2PWPinyin

__all__ = ["G2PWPinyin"]
