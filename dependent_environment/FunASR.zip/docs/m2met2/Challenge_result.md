# Challenge Result
The following table shows the final results of the competition, where Sub-track1 represents the sub-track under fixed training condition and Sub-track 2 represents the sub-track under the open training condition. All result in this table is cp-CER (%). The rankings in the table are the combined rankings of the two sub-tracks as all teams' submissions met the requirements of the sub-track under fixed training condition.
| Rank &nbsp; &nbsp; | Team Name &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  | Sub-track1 &nbsp; &nbsp; | Sub-track2 &nbsp; &nbsp; | paper |
|------|----------------------|------------|------------|------------------------|
| 1    | Ximalaya Speech Team | 11.27      | 11.27      |                        |
| 2    | 小马达                | 18.64      | 18.64      |                        |
| 3    | AIzyzx               | 22.83      | 22.83      |                        |
| 4    | AsrSpeeder           | /          | 23.51      |                        |
| 5    | zyxlhz               | 24.82      | 24.82      |                        |
| 6    | CMCAI                | 26.11      | /          |                        |
| 7    | Volcspeech           | 34.21      | 34.21      |                        |
| 8    | 鉴往知来              | 40.14      | 40.14      |                        |
| 9    | baseline             | 41.55      | 41.55      |                        |
| 10   | DAICT                | 41.64      |            |                        |
