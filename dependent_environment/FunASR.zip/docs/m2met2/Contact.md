# Contact
If you have any questions about M2MeT2.0 challenge, please contact us by

- email: [m2met.alimeeting@gmail.com](mailto:m2met.alimeeting@gmail.com)
