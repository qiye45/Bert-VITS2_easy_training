# Organizers
***Lei Xie, Professor, AISHELL foundation, China***

Email: [lxie@nwpu.edu.cn](mailto:lxie@nwpu.edu.cn)

<img src="images/lxie.jpeg" alt="lxie" width="20%">


***Kong Aik Lee, Senior Scientist at Institute for Infocomm Research, A\*Star, Singapore***

Email: [kongaik.lee@ieee.org](mailto:kongaik.lee@ieee.org)

<img src="images/kong.png" alt="kong" width="20%">


***Zhijie Yan, Principal Engineer at Alibaba, China***
Email: [zhijie.yzj@alibaba-inc.com](mailto:zhijie.yzj@alibaba-inc.com)

<img src="images/zhijie.jpg" alt="zhijie" width="20%">

***Shiliang Zhang, Senior Engineer at Alibaba, China***
Email: [sly.zsl@alibaba-inc.com](mailto:sly.zsl@alibaba-inc.com)

<img src="images/zsl.JPG" alt="zsl" width="20%">

***Yanmin Qian, Professor, Shanghai Jiao Tong University, China***

Email: [yanminqian@sjtu.edu.cn](mailto:yanminqian@sjtu.edu.cn)

<img src="images/qian.jpeg" alt="qian" width="20%">

***Zhuo Chen, Applied Scientist in Microsoft, USA***

Email: [zhuc@microsoft.com](mailto:zhuc@microsoft.com)

<img src="images/chenzhuo.jpg" alt="chenzhuo" width="20%">

***Jian Wu, Applied Scientist in Microsoft, USA***

Email: [wujian@microsoft.com](mailto:wujian@microsoft.com)

<img src="images/wujian.jpg" alt="wujian" width="20%">

***Hui Bu, CEO, AISHELL foundation, China***

Email: [buhui@aishelldata.com](mailto:buhui@aishelldata.com)

<img src="images/buhui.jpeg" alt="buhui" width="20%">
