# Copyright (c) Alibaba, Inc. and its affiliates.
from .face_attribute_recognition import FaceAttributeRecognition
