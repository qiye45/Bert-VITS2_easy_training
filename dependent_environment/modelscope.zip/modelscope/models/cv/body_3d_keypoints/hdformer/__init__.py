# Copyright (c) Alibaba, Inc. and its affiliates.
from .hdformer_detector import HDFormerDetector
