# Copyright (c) Alibaba, Inc. and its affiliates.
from .single_level_roi_extractor import SingleRoINExtractor

__all__ = ['SingleRoINExtractor']
