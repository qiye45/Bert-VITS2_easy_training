# NOTE

`DiT_ImageNet_Demo.ipynb`, `SiT_ImageNet_Demo.ipynb`, `ViViT-demo.ipynb`, `UViT_ImageNet_demo.ipynb` are moved to the [modelscope-classroom repo](https://github.com/modelscope/modelscope-classroom)
