PYTHONPATH=. python examples/pytorch/auto_speech_recognition/finetune_speech_recognition.py
