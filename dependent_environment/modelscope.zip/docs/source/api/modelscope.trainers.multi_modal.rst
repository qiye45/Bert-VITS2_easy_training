modelscope.trainers.multi_modal
=======================

.. automodule:: modelscope.trainers.multi_modal

.. currentmodule:: modelscope.trainers.multi_modal


.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    clip.CLIPTrainer
    team.TEAMImgClsTrainer
    ofa.OFATrainer
    mplug.MPlugTrainer
    mgeo_ranking_trainer.MGeoRankingTrainer
