modelscope.pipelines.base
=========================

.. automodule:: modelscope.pipelines.base

.. currentmodule:: modelscope.pipelines.base

.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    Pipeline
    DistributedPipeline
