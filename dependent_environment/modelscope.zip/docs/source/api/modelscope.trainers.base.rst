modelscope.trainers.base
========================

.. automodule:: modelscope.trainers.base

.. currentmodule:: modelscope.trainers.base

.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    BaseTrainer
    DummyTrainer
