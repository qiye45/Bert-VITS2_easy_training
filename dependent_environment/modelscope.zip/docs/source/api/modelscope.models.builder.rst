modelscope.models.builder
=========================

.. automodule:: modelscope.models.builder

.. currentmodule:: modelscope.models.builder


.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    build_model
    build_backbone
    build_head
