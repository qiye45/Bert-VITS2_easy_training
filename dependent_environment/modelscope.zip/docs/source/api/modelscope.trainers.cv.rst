modelscope.trainers.cv
=======================

.. automodule:: modelscope.trainers.cv

.. currentmodule:: modelscope.trainers.cv


.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    ImagePortraitEnhancementTrainer
