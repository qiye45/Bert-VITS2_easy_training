modelscope.preprocessors.builder
======================

.. automodule:: modelscope.preprocessors.builder

.. currentmodule:: modelscope.preprocessors.builder


.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    build_preprocessor
