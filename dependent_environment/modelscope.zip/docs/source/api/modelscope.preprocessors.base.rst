modelscope.preprocessors.base
======================

.. automodule:: modelscope.preprocessors.base

.. currentmodule:: modelscope.preprocessors.base


.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    Preprocessor
