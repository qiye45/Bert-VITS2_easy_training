modelscope.pipelines.science
=======================

.. automodule:: modelscope.pipelines.science

.. currentmodule:: modelscope.pipelines.science


.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    ProteinStructurePipeline
