modelscope.trainers.builder
===========================

.. automodule:: modelscope.trainers.builder

.. currentmodule:: modelscope.trainers.builder


.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    build_trainer
