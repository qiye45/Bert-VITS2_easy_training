modelscope.pipelines.audio
=======================

.. automodule:: modelscope.pipelines.audio

.. currentmodule:: modelscope.pipelines.audio


.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    ANSPipeline
    AutomaticSpeechRecognitionPipeline
    InverseTextProcessingPipeline
    KWSFarfieldPipeline
    KeyWordSpottingKwsbpPipeline
    LinearAECPipeline
    TextToSpeechSambertHifiganPipeline
