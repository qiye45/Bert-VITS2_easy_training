modelscope.preprocessors.video
====================

.. automodule:: modelscope.preprocessors.video

.. currentmodule:: modelscope.preprocessors.video


.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    ReadVideoData
    kinetics400_tranform
    _interval_based_sampling
    _decode_video_frames_list
    _decode_video
    KineticsResizedCrop
    MovieSceneSegmentationPreprocessor
