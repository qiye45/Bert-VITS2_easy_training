modelscope.msdatasets
=====================

.. automodule:: modelscope.msdatasets

.. currentmodule:: modelscope.msdatasets

.. toctree::
   :maxdepth: 2
   :caption: Dataset Api

   dataset     <modelscope.msdatasets.ms_dataset>
   cv    <modelscope.msdatasets.cv>
