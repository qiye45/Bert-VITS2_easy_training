modelscope.pipelines.builder
============================

.. automodule:: modelscope.pipelines.builder

.. currentmodule:: modelscope.pipelines.builder


.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    build_pipeline
    pipeline
