modelscope.msdatasets.dataset_cls
====================

.. automodule:: modelscope.msdatasets.dataset_cls

.. currentmodule:: modelscope.msdatasets.dataset_cls


.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    ExternalDataset
    NativeIterableDataset
