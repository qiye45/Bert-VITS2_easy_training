a = 1
b = dict(c=[1, 2, 3], d='dd')
